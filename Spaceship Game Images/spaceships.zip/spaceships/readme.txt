You are free to do anything with these graphics beside selling them. Using them for commercial projects is fine.

Note that I'm far from being an artist and these graphics are primarily meant as placeholders.

Not all spaceships are available in all sizes.

Dave Toulouse
www.over00.com